package pages;

public class cadastroPage {


}
