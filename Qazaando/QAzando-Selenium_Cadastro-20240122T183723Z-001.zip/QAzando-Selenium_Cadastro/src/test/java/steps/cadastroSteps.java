package steps;

import cucumber.api.java.es.Dado;
import cucumber.api.java.it.Quando;
import cucumber.api.java.pt.Entao;
import runner.RunCucumberTest;

public class cadastroSteps extends RunCucumberTest {


    @Quando("^eu preencho o formulario de cadastro$")
    public void eu_preencho_o_formulario_de_cadastro() throws Throwable {

    }

    @Quando("^clico em registrar$")
    public void clico_em_registrar() throws Throwable {

    }

    @Entao("^vejo a mensagem de cadastro realizado com sucesso$")
    public void vejo_a_mensagem_de_cadastro_realizado_com_sucesso() throws Throwable {

    }



}
